import React from 'react';

import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';

const baseUrl = process.env.REACT_APP_BACKEND_URL;
const apiToken = process.env.REACT_APP_API_TOKEN;

class EditComponent extends React.Component{

 constructor(props){
   super(props);
   this.state = {
     campNumber: "",
     campDescription: "",
     campAdress: "",
     campNome: "",
     campLat: "",
     campLon: "",
     campMax: "",
     campMin: ""
   }
 } 

 render(){
  return (
    <div>
      <div className="form-row justify-content-center">  
        <div className="form-group col-md-12">
          <label htmlFor="input1">Destinatário,Sessão</label>
          <textarea cols="60" rows="5" type="text" className="form-control"  placeholder="5535912346578,sessao1&#10;5535912346578,sessao2&#10;5535912346578,sessao3" value={this.state.campNumber} onChange={(value)=> this.setState({campNumber:value.target.value})}/>
        </div>
        <div className="form-group col-md-12">
          <label htmlFor="input2">Endereço</label>
          <textarea cols="60" rows="5" type="text" className="form-control"  placeholder="Endereço" value={this.state.campAdress} onChange={(value)=> this.setState({campAdress:value.target.value})}/>
        </div>
        <div className="form-group col-md-4">
          <label htmlFor="input1">Nome</label>
          <input type="text" className="form-control"  placeholder="Nome" value={this.state.campNome} onChange={(value)=> this.setState({campNome:value.target.value})}/>
        </div>
        <div className="form-group col-md-4">
          <label htmlFor="input1">Latitude</label>
          <input type="number" className="form-control"  placeholder="Latitude" value={this.state.campLat} onChange={(value)=> this.setState({campLat:value.target.value})}/>
        </div>
        <div className="form-group col-md-4">
          <label htmlFor="input1">Longitude</label>
          <input type="number" className="form-control"  placeholder="Longitude" value={this.state.campLon} onChange={(value)=> this.setState({campLon:value.target.value})}/>
        </div>
        <div className="form-group col-md-6">
          <label htmlFor="input1">Tempo minímo</label>
          <input type="number" className="form-control"  placeholder="Tempo mínimo (segundos)" value={this.state.campMin} onChange={(value)=> this.setState({campMin:value.target.value})}/>
        </div>
        <div className="form-group col-md-6">
          <label htmlFor="input1">Tempo máximo</label>
          <input type="number" className="form-control"  placeholder="Tempo máximo (segundos)" value={this.state.campMax} onChange={(value)=> this.setState({campMax:value.target.value})}/>
        </div>
      </div>
      <button type="submit" className="btn btn-primary" onClick={()=>this.sendAction()}>Enviar</button>
    </div>
  );
}

async sendAction(){
  const usersTextArea = this.state.campNumber.split('\n');
  const timer = ms => new Promise(res => setTimeout(res, ms))
  function randomIntFromInterval(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min)
  }
  for (const user of usersTextArea){
    const rndInt = randomIntFromInterval(this.state.campMin, this.state.campMax)
    await timer(rndInt * 1000)
    const phone = user.split(',')[0];
    const sessao = user.split(',')[1];
    var data = {
      "number": phone,
      "locationMessage": {
        "name": this.state.campNome,
        "address": this.state.campDescription.replace(/\n/g, "\n"),
        "latitude": parseFloat(this.state.campLat),
        "longitude": parseFloat(this.state.campLon)
      },
      "options": {
        "delay": 1200
      }
    }
    var config = {
      method: 'post',
      url: baseUrl + '/message/sendLocation/' + sessao,
      headers: {
        'apikey': apiToken,
        'Content-Type': 'application/json'
      },
      data : data
    };
    
    axios(config)
    .then(function (response) {
      console.log(JSON.stringify(response.data));
    })
    .catch(function (error) {
      console.log(error);
      alert('© BOT-ZDG - ' + error)
    });
  }
}

}

export default EditComponent;