import React from 'react';

import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';

const baseUrl = process.env.REACT_APP_BACKEND_URL;
const apiToken = process.env.REACT_APP_API_TOKEN;

class EditComponent extends React.Component{

 constructor(props){
   super(props);
   this.state = {
     campNumber: "",
     campDescription: "",
     campTitle: "",
     campFooter: "",
     campBtn1: "",
     campBtn2: "",
     campBtn3: "",
     campMax: "",
     campMin: ""
   }
 } 

 render(){
  return (
    <div>
      <div className="form-row justify-content-center">  
        <div className="form-group col-md-12">
          <label htmlFor="input1">Destinatário,Sessão</label>
          <textarea cols="60" rows="5" type="text" className="form-control"  placeholder="5535912346578,sessao1&#10;5535912346578,sessao2&#10;5535912346578,sessao3" value={this.state.campNumber} onChange={(value)=> this.setState({campNumber:value.target.value})}/>
        </div>
        <div className="form-group col-md-12">
          <label htmlFor="input2">Descrição</label>
          <textarea cols="60" rows="5" type="text" className="form-control"  placeholder="Descrição" value={this.state.campDescription} onChange={(value)=> this.setState({campDescription:value.target.value})}/>
        </div>
        <div className="form-group col-md-6">
          <label htmlFor="input1">Título</label>
          <input type="text" className="form-control"  placeholder="Título" value={this.state.campTitle} onChange={(value)=> this.setState({campTitle:value.target.value})}/>
        </div>
        <div className="form-group col-md-6">
          <label htmlFor="input1">Footer</label>
          <input type="text" className="form-control"  placeholder="Footer" value={this.state.campFooter} onChange={(value)=> this.setState({campFooter:value.target.value})}/>
        </div>
        <div className="form-group col-md-4">
          <label htmlFor="input1">Botão 1</label>
          <input type="text" className="form-control"  placeholder="Botão 1" value={this.state.campBtn1} onChange={(value)=> this.setState({campBtn1:value.target.value})}/>
        </div>
        <div className="form-group col-md-4">
          <label htmlFor="input1">Botão 2</label>
          <input type="text" className="form-control"  placeholder="Botão 2" value={this.state.campBtn2} onChange={(value)=> this.setState({campBtn2:value.target.value})}/>
        </div>
        <div className="form-group col-md-4">
          <label htmlFor="input1">Botão 3</label>
          <input type="text" className="form-control"  placeholder="Botão 3" value={this.state.campBtn3} onChange={(value)=> this.setState({campBtn3:value.target.value})}/>
        </div>
        <div className="form-group col-md-6">
          <label htmlFor="input1">Tempo minímo</label>
          <input type="number" className="form-control"  placeholder="Tempo mínimo (segundos)" value={this.state.campMin} onChange={(value)=> this.setState({campMin:value.target.value})}/>
        </div>
        <div className="form-group col-md-6">
          <label htmlFor="input1">Tempo máximo</label>
          <input type="number" className="form-control"  placeholder="Tempo máximo (segundos)" value={this.state.campMax} onChange={(value)=> this.setState({campMax:value.target.value})}/>
        </div>
      </div>
      <button type="submit" className="btn btn-primary" onClick={()=>this.sendAction()}>Enviar</button>
    </div>
  );
}

async sendAction(){
  const usersTextArea = this.state.campNumber.split('\n');
  const timer = ms => new Promise(res => setTimeout(res, ms))
  function randomIntFromInterval(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min)
  }
  for (const user of usersTextArea){
    const rndInt = randomIntFromInterval(this.state.campMin, this.state.campMax)
    await timer(rndInt * 1000)
    const phone = user.split(',')[0];
    const sessao = user.split(',')[1];
    var data = {
      "number": phone,
      "options": {
        "delay": 1200
      },
      "buttonMessage": {
        "title": this.state.campTitle,
        "description": this.state.campDescription.replace(/\n/g, "\n"),
        "footerText": this.state.campFooter,
        "buttons": [
          {
            "buttonText": this.state.campBtn1,
            "buttonId": "1"
          },
          {
            "buttonText": this.state.campBtn2,
            "buttonId": "2"
          },
          {
            "buttonText": this.state.campBtn3,
            "buttonId": "3"
          }
        ]
      }
    }
    var config = {
      method: 'post',
      url: baseUrl + '/message/sendButtons/' + sessao,
      headers: {
        'apikey': apiToken,
        'Content-Type': 'application/json'
      },
      data : data
    };
    
    axios(config)
    .then(function (response) {
      console.log(JSON.stringify(response.data));
    })
    .catch(function (error) {
      console.log(error);
      alert('© BOT-ZDG - ' + error)
    });
  }
}

}

export default EditComponent;